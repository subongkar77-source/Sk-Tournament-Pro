package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.RetrofitClient
import com.example.model.Tournament
import com.example.model.Transaction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID

class FFViewModel : ViewModel() {

    private val _isSimulatedMode = MutableStateFlow(true)
    val isSimulatedMode: StateFlow<Boolean> = _isSimulatedMode.asStateFlow()

    private val _tournaments = MutableStateFlow<List<Tournament>>(emptyList())
    val tournaments: StateFlow<List<Tournament>> = _tournaments.asStateFlow()

    private val _pendingTransactions = MutableStateFlow<List<Transaction>>(emptyList())
    val pendingTransactions: StateFlow<List<Transaction>> = _pendingTransactions.asStateFlow()

    private val _allTransactions = MutableStateFlow<List<Transaction>>(emptyList())
    val allTransactions: StateFlow<List<Transaction>> = _allTransactions.asStateFlow()

    private val _userBalance = MutableStateFlow(500.0) // initial wallet balance in INR/Credits
    val userBalance: StateFlow<Double> = _userBalance.asStateFlow()

    private val _isUploading = MutableStateFlow(false)
    val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    // Mock/Profile Data
    val currentUserId = "user_freefire_99"
    val currentUserName = "GamerTitan"
    val defaultGameId = "TITAN_FF_55"

    // Local In-Memory Store for Simulator (Mock Backend)
    private val mockTournaments = mutableListOf<Tournament>()
    private val mockTransactions = mutableListOf<Transaction>()

    init {
        setupMockData()
        loadInitialData()
    }

    private fun setupMockData() {
        mockTournaments.addAll(
            listOf(
                Tournament(
                    id = "t_1",
                    title = "Grandmaster Solo Clash",
                    type = "Solo",
                    map = "Bermuda",
                    date = "June 10, 2026",
                    time = "18:00 IST",
                    entryFee = 50,
                    prizePool = 1000,
                    slotsAvailable = 38,
                    slotsTotal = 50,
                    status = "Registering"
                ),
                Tournament(
                    id = "t_2",
                    title = "Clash Squad Pro League",
                    type = "CS Rd 4",
                    map = "Purgatory",
                    date = "June 11, 2026",
                    time = "19:30 IST",
                    entryFee = 100,
                    prizePool = 2500,
                    slotsAvailable = 4,
                    slotsTotal = 16,
                    status = "Registering"
                ),
                Tournament(
                    id = "t_3",
                    title = "Lone Wolf Duel Elite",
                    type = "Lone Wolf",
                    map = "Science Museum",
                    date = "June 12, 2026",
                    time = "15:00 IST",
                    entryFee = 30,
                    prizePool = 500,
                    slotsAvailable = 15,
                    slotsTotal = 32,
                    status = "Registering"
                ),
                Tournament(
                    id = "t_4",
                    title = "Weekend Rush Hour (Duo)",
                    type = "Solo Match",
                    map = "Kalahari",
                    date = "June 13, 2026",
                    time = "21:00 IST",
                    entryFee = 40,
                    prizePool = 800,
                    slotsAvailable = 0,
                    slotsTotal = 40,
                    status = "Completed"
                )
            )
        )

        mockTransactions.addAll(
            listOf(
                Transaction(
                    id = "TX_1001",
                    userId = currentUserId,
                    userName = currentUserName,
                    type = "Deposit",
                    amount = 200.0,
                    paymentMethod = "UPI",
                    screenshotUrl = "https://images.unsplash.com/photo-1616077168079-7e09a677fb2c?auto=format&fit=crop&q=80&w=400",
                    status = "approved",
                    timestamp = System.currentTimeMillis() - 86400000,
                    gameId = "TITAN_FF_55"
                ),
                Transaction(
                    id = "TX_1002",
                    userId = currentUserId,
                    userName = currentUserName,
                    type = "Withdrawal",
                    amount = 50.0,
                    paymentMethod = "Paytm",
                    screenshotUrl = null,
                    status = "approved",
                    timestamp = System.currentTimeMillis() - 43200000,
                    gameId = "TITAN_FF_55"
                ),
                Transaction(
                    id = "TX_1003",
                    userId = "user_alpha_32",
                    userName = "SniperKing",
                    type = "Deposit",
                    amount = 150.0,
                    paymentMethod = "UPI",
                    screenshotUrl = "https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?auto=format&fit=crop&q=80&w=400",
                    status = "pending",
                    timestamp = System.currentTimeMillis() - 10000000,
                    gameId = "SNIPER_ID"
                ),
                Transaction(
                    id = "TX_1004",
                    userId = "user_beta_77",
                    userName = "RushGirl",
                    type = "Withdrawal",
                    amount = 300.0,
                    paymentMethod = "Bkash",
                    screenshotUrl = null,
                    status = "pending",
                    timestamp = System.currentTimeMillis() - 5000000,
                    gameId = "RUSH_G_99"
                )
            )
        )
    }

    private fun loadInitialData() {
        fetchTournaments()
        fetchTransactions()
        fetchPendingTransactions()
    }

    fun setSimulatedMode(simulated: Boolean) {
        _isSimulatedMode.value = simulated
        _uiMessage.value = if (simulated) "Switched to Simulator (Offline Mode)" else "Switched to Live Retrofit Network Mode"
        loadInitialData()
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    fun fetchTournaments() {
        viewModelScope.launch {
            if (_isSimulatedMode.value) {
                _tournaments.value = mockTournaments
            } else {
                try {
                    val response = RetrofitClient.apiService.getTournaments()
                    _tournaments.value = response
                } catch (e: Exception) {
                    Log.e("FFViewModel", "Error fetching tournaments, falling back to simulated data", e)
                    _uiMessage.value = "Retrofit fallback: Base URL unavailable. Loading mock tournament data."
                    _tournaments.value = mockTournaments
                }
            }
        }
    }

    fun fetchTransactions() {
        viewModelScope.launch {
            if (_isSimulatedMode.value) {
                // Fetch our own and filter
                val userTx = mockTransactions.filter { it.userId == currentUserId }
                _allTransactions.value = userTx
                // Calculate balance from approved deposits and withdrawals
                var balance = 500.0 // Starting
                mockTransactions.filter { it.userId == currentUserId && it.status == "approved" }.forEach { tx ->
                    if (tx.type == "Deposit") balance += tx.amount
                    else if (tx.type == "Withdrawal") balance -= tx.amount
                }
                _userBalance.value = balance
            } else {
                try {
                    val list = RetrofitClient.apiService.getUserTransactions(currentUserId)
                    _allTransactions.value = list

                    // Dynamic summation
                    var balance = 500.0
                    list.filter { it.status == "approved" }.forEach { tx ->
                        if (tx.type == "Deposit") balance += tx.amount
                        else if (tx.type == "Withdrawal") balance -= tx.amount
                    }
                    _userBalance.value = balance
                } catch (e: Exception) {
                    Log.e("FFViewModel", "Error fetching user transactions", e)
                    // fallback
                    val userTx = mockTransactions.filter { it.userId == currentUserId }
                    _allTransactions.value = userTx
                    _userBalance.value = 350.0 // Mock fallback balance
                }
            }
        }
    }

    fun fetchPendingTransactions() {
        viewModelScope.launch {
            if (_isSimulatedMode.value) {
                _pendingTransactions.value = mockTransactions.filter { it.status == "pending" }
            } else {
                try {
                    val response = RetrofitClient.apiService.getPendingTransactions()
                    _pendingTransactions.value = response.filter { it.status == "pending" }
                } catch (e: Exception) {
                    Log.e("FFViewModel", "Error fetching pending transactions", e)
                    _pendingTransactions.value = mockTransactions.filter { it.status == "pending" }
                }
            }
        }
    }

    fun uploadDepositProof(context: Context, imageUri: Uri, amount: Double, paymentMethod: String, gameId: String) {
        viewModelScope.launch {
            _isUploading.value = true
            if (_isSimulatedMode.value) {
                // Simulate lag
                kotlinx.coroutines.delay(1200)
                val newTx = Transaction(
                    id = "TX_" + UUID.randomUUID().toString().take(6).uppercase(),
                    userId = currentUserId,
                    userName = currentUserName,
                    type = "Deposit",
                    amount = amount,
                    paymentMethod = paymentMethod,
                    screenshotUrl = imageUri.toString(), // URI reference local for display
                    status = "pending",
                    timestamp = System.currentTimeMillis(),
                    gameId = gameId
                )
                mockTransactions.add(newTx)
                _isUploading.value = false
                _uiMessage.value = "Payment Proof Submitted (Pending Admin Review)!"
                fetchTransactions()
                fetchPendingTransactions()
            } else {
                try {
                    val contentResolver = context.contentResolver
                    val fileType = contentResolver.getType(imageUri) ?: "image/jpeg"
                    val inputStream = contentResolver.openInputStream(imageUri)
                    val bytes = inputStream?.readBytes() ?: byteArrayOf()
                    
                    val requestFile = bytes.toRequestBody(fileType.toMediaTypeOrNull(), 0, bytes.size)
                    val screenshotPart = MultipartBody.Part.createFormData("screenshot", "payment_proof.jpg", requestFile)

                    val userIdPart = currentUserId.toRequestBody("text/plain".toMediaTypeOrNull())
                    val userNamePart = currentUserName.toRequestBody("text/plain".toMediaTypeOrNull())
                    val amountPart = amount.toString().toRequestBody("text/plain".toMediaTypeOrNull())
                    val methodPart = paymentMethod.toRequestBody("text/plain".toMediaTypeOrNull())
                    val gameIdPart = gameId.toRequestBody("text/plain".toMediaTypeOrNull())

                    val response = RetrofitClient.apiService.uploadDepositProof(
                        screenshot = screenshotPart,
                        userId = userIdPart,
                        userName = userNamePart,
                        amount = amountPart,
                        paymentMethod = methodPart,
                        gameId = gameIdPart
                    )

                    _isUploading.value = false
                    _uiMessage.value = "API Deposit Proof Upload Success!"
                    fetchTransactions()
                    fetchPendingTransactions()
                } catch (e: Exception) {
                    Log.e("FFViewModel", "Error uploading via Retrofit, performing simulated upload", e)
                    // If real request fails, fallback simulate so the flow isn't visually broken
                    kotlinx.coroutines.delay(800)
                    val newTx = Transaction(
                        id = "TX_M" + UUID.randomUUID().toString().take(5).uppercase(),
                        userId = currentUserId,
                        userName = currentUserName,
                        type = "Deposit",
                        amount = amount,
                        paymentMethod = paymentMethod,
                        screenshotUrl = imageUri.toString(),
                        status = "pending",
                        timestamp = System.currentTimeMillis(),
                        gameId = gameId
                    )
                    mockTransactions.add(newTx)
                    _isUploading.value = false
                    _uiMessage.value = "API Server offline. Executed fallback Simulation Deposit upload!"
                    fetchTransactions()
                    fetchPendingTransactions()
                }
            }
        }
    }

    fun submitWithdrawal(amount: Double, paymentMethod: String, gameId: String) {
        viewModelScope.launch {
            if (_userBalance.value < amount) {
                _uiMessage.value = "Insufficient wallet balance to request withdrawal!"
                return@launch
            }
            _isUploading.value = true
            if (_isSimulatedMode.value) {
                kotlinx.coroutines.delay(800)
                val newTx = Transaction(
                    id = "TX_" + UUID.randomUUID().toString().take(6).uppercase(),
                    userId = currentUserId,
                    userName = currentUserName,
                    type = "Withdrawal",
                    amount = amount,
                    paymentMethod = paymentMethod,
                    screenshotUrl = null,
                    status = "pending",
                    timestamp = System.currentTimeMillis(),
                    gameId = gameId
                )
                mockTransactions.add(newTx)
                _isUploading.value = false
                _uiMessage.value = "Withdrawal Request Submitted (Pending Review)!"
                fetchTransactions()
                fetchPendingTransactions()
            } else {
                try {
                    val payload = mapOf(
                        "userId" to currentUserId,
                        "userName" to currentUserName,
                        "amount" to amount.toString(),
                        "paymentMethod" to paymentMethod,
                        "gameId" to gameId,
                        "type" to "Withdrawal"
                    )
                    RetrofitClient.apiService.requestWithdrawal(payload)
                    _isUploading.value = false
                    _uiMessage.value = "API Withdrawal Requested!"
                    fetchTransactions()
                    fetchPendingTransactions()
                } catch (e: Exception) {
                    Log.e("FFViewModel", "Error posting withdrawal", e)
                    // mock fallback
                    val newTx = Transaction(
                        id = "TX_W" + UUID.randomUUID().toString().take(5).uppercase(),
                        userId = currentUserId,
                        userName = currentUserName,
                        type = "Withdrawal",
                        amount = amount,
                        paymentMethod = paymentMethod,
                        screenshotUrl = null,
                        status = "pending",
                        timestamp = System.currentTimeMillis(),
                        gameId = gameId
                    )
                    mockTransactions.add(newTx)
                    _isUploading.value = false
                    _uiMessage.value = "Server offline. Executed fallback Simulated Withdrawal!"
                    fetchTransactions()
                    fetchPendingTransactions()
                }
            }
        }
    }

    fun approveTransaction(transactionId: String) {
        viewModelScope.launch {
            if (_isSimulatedMode.value) {
                val index = mockTransactions.indexOfFirst { it.id == transactionId }
                if (index != -1) {
                    val currentTx = mockTransactions[index]
                    mockTransactions[index] = currentTx.copy(status = "approved")
                    _uiMessage.value = "Approved Transaction $transactionId successfully!"
                    fetchTransactions()
                    fetchPendingTransactions()
                }
            } else {
                try {
                    RetrofitClient.apiService.updateTransactionStatus(
                        id = transactionId,
                        statusPayload = mapOf("status" to "approved")
                    )
                    _uiMessage.value = "API: Transaction Approved!"
                    fetchTransactions()
                    fetchPendingTransactions()
                } catch (e: Exception) {
                    Log.e("FFViewModel", "Error approving transaction status via Retrofit", e)
                    // fallback approve
                    val index = mockTransactions.indexOfFirst { it.id == transactionId }
                    if (index != -1) {
                        val currentTx = mockTransactions[index]
                        mockTransactions[index] = currentTx.copy(status = "approved")
                    }
                    _uiMessage.value = "Server offline. Simulated locally instead: Approved $transactionId!"
                    fetchTransactions()
                    fetchPendingTransactions()
                }
            }
        }
    }

    fun rejectTransaction(transactionId: String) {
        viewModelScope.launch {
            if (_isSimulatedMode.value) {
                val index = mockTransactions.indexOfFirst { it.id == transactionId }
                if (index != -1) {
                    val currentTx = mockTransactions[index]
                    mockTransactions[index] = currentTx.copy(status = "rejected")
                    _uiMessage.value = "Rejected Transaction $transactionId successfully."
                    fetchTransactions()
                    fetchPendingTransactions()
                }
            } else {
                try {
                    RetrofitClient.apiService.updateTransactionStatus(
                        id = transactionId,
                        statusPayload = mapOf("status" to "rejected")
                    )
                    _uiMessage.value = "API: Transaction Rejected!"
                    fetchTransactions()
                    fetchPendingTransactions()
                } catch (e: Exception) {
                    Log.e("FFViewModel", "Error rejecting transaction status via Retrofit", e)
                    val index = mockTransactions.indexOfFirst { it.id == transactionId }
                    if (index != -1) {
                        val currentTx = mockTransactions[index]
                        mockTransactions[index] = currentTx.copy(status = "rejected")
                    }
                    _uiMessage.value = "Server offline. Simulated locally instead: Rejected $transactionId."
                    fetchTransactions()
                    fetchPendingTransactions()
                }
            }
        }
    }

    // Direct game registration simulator to enrich the app!
    fun registerForTournament(tournamentId: String) {
        viewModelScope.launch {
            val index = mockTournaments.indexOfFirst { it.id == tournamentId }
            if (index != -1) {
                val t = mockTournaments[index]
                if (t.slotsAvailable <= 0) {
                    _uiMessage.value = "No slots available for this tournament!"
                    return@launch
                }
                if (_userBalance.value < t.entryFee) {
                    _uiMessage.value = "Insufficient wallet balance to register! Please deposit credits."
                    return@launch
                }

                // Deduct entry fee
                _userBalance.value -= t.entryFee
                mockTournaments[index] = t.copy(slotsAvailable = t.slotsAvailable - 1)

                // Add record tx
                val newTx = Transaction(
                    id = "TX_REG_" + UUID.randomUUID().toString().take(4).uppercase(),
                    userId = currentUserId,
                    userName = currentUserName,
                    type = "Withdrawal",
                    amount = t.entryFee.toDouble(),
                    paymentMethod = "Entry Fee Info",
                    screenshotUrl = null,
                    status = "approved",
                    timestamp = System.currentTimeMillis(),
                    gameId = defaultGameId
                )
                mockTransactions.add(newTx)
                _uiMessage.value = "Successfully registered for ${t.title}!"
                fetchTournaments()
                fetchTransactions()
            }
        }
    }
}
