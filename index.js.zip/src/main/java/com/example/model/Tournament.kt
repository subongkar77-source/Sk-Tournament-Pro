package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Tournament(
    val id: String,
    val title: String,
    val type: String, // "Solo" | "Clash Squad" | "Lone Wolf"
    val map: String,  // e.g. "Bermuda", "Purgatory"
    val date: String,
    val time: String,
    val entryFee: Int,
    val prizePool: Int,
    val slotsAvailable: Int,
    val slotsTotal: Int,
    val status: String // "Registering" | "Ongoing" | "Completed"
)
