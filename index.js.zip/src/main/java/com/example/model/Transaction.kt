package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Transaction(
    val id: String,
    val userId: String,
    val userName: String,
    val type: String, // "Deposit" | "Withdrawal"
    val amount: Double,
    val paymentMethod: String, // "UPI" | "Paytm" | "Bkash" | "Card"
    val screenshotUrl: String?, // Saved screenshot image URL
    val status: String, // "pending" | "approved" | "rejected"
    val timestamp: Long,
    val gameId: String? // User's Free Fire In-Game Character Name/ID
)
