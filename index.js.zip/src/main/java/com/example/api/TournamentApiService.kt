package com.example.api

import com.example.model.Tournament
import com.example.model.Transaction
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*

interface TournamentApiService {

    // --- Tournaments ---
    @GET("api/tournaments")
    suspend fun getTournaments(): List<Tournament>

    @POST("api/tournaments")
    suspend fun createTournament(@Body tournament: Tournament): Tournament

    // --- Transactions (User Side) ---
    @GET("api/transactions/user/{userId}")
    suspend fun getUserTransactions(@Path("userId") userId: String): List<Transaction>

    // Upload payment screenshot with details as form data
    @Multipart
    @POST("api/transactions/deposit")
    suspend fun uploadDepositProof(
        @Part screenshot: MultipartBody.Part,
        @Part("userId") userId: RequestBody,
        @Part("userName") userName: RequestBody,
        @Part("amount") amount: RequestBody,
        @Part("paymentMethod") paymentMethod: RequestBody,
        @Part("gameId") gameId: RequestBody
    ): Transaction

    // Submit withdrawal request
    @POST("api/transactions/withdraw")
    suspend fun requestWithdrawal(
        @Body payload: Map<String, String> // e.g. keys: userId, userName, amount, paymentMethod, gameId
    ): Transaction

    // --- Admin Operations ---
    // Fetch pending transactions for manual verification
    @GET("api/admin/transactions/pending")
    suspend fun getPendingTransactions(): List<Transaction>

    // Update transaction status (approve/reject)
    @PUT("api/admin/transactions/{id}/status")
    suspend fun updateTransactionStatus(
        @Path("id") id: String,
        @Body statusPayload: Map<String, String> // e.g., "status" to "approved" or "rejected"
    ): Transaction
}
