package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Transaction
import com.example.viewmodel.FFViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun WalletScreen(viewModel: FFViewModel) {
    val context = LocalContext.current
    val balance by viewModel.userBalance.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val isUploading by viewModel.isUploading.collectAsState()

    var selectedTab by remember { mutableStateOf("deposit") } // "deposit" or "withdraw"

    // Deposit Form State
    var depositAmount by remember { mutableStateOf("100") }
    var paymentMethod by remember { mutableStateOf("UPI") }
    var gameId by remember { mutableStateOf(viewModel.defaultGameId) }
    var screenshotUri by remember { mutableStateOf<Uri?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }

    // Withdrawal Form State
    var withdrawAmount by remember { mutableStateOf("100") }
    var withdrawMethod by remember { mutableStateOf("Paytm") }
    var withdrawGameId by remember { mutableStateOf(viewModel.defaultGameId) }
    var withdrawError by remember { mutableStateOf<String?>(null) }

    // File Picker Launcher
    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            screenshotUri = uri
            formError = null
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF12141C))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Core Wallet Balance Card
        item {
            BalanceCard(balance)
        }

        // Operation Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E2230), RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                TabButton(
                    title = "Deposit Credits",
                    selected = selectedTab == "deposit",
                    onClick = { selectedTab = "deposit" },
                    modifier = Modifier.weight(1f)
                )
                TabButton(
                    title = "Withdraw Wins",
                    selected = selectedTab == "withdraw",
                    onClick = { selectedTab = "withdraw" },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Selected Operation Form
        item {
            if (selectedTab == "deposit") {
                // Deposit form
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Add Coins to Wallet",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Transfer to our payment options: UPI/Merchant ID 'freefire@tournament', Paytm, or bKash. Then upload screenshot of payment below.",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )

                        // Amount field
                        OutlinedTextField(
                            value = depositAmount,
                            onValueChange = { depositAmount = it },
                            label = { Text("Amount (INR/Coins)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = TextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color(0xFF12141C),
                                unfocusedContainerColor = Color(0xFF12141C),
                                focusedLabelColor = Color(0xFFFFA502),
                                cursorColor = Color(0xFFFFA502)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("deposit_amount_field")
                        )

                        // Amount Quick Chips
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("50", "100", "200", "500").forEach { amount ->
                                AssistChip(
                                    onClick = { depositAmount = amount },
                                    label = { Text(amount) },
                                    colors = AssistChipDefaults.assistChipColors(
                                        labelColor = if (depositAmount == amount) Color.White else Color.LightGray,
                                        containerColor = if (depositAmount == amount) Color(0xFFFF4E50) else Color(0xFF2E3349)
                                    ),
                                    border = null
                                )
                            }
                        }

                        // Payment Channel
                        Text("Select Channel", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("UPI", "Paytm", "Bkash").forEach { method ->
                                FilterChip(
                                    selected = paymentMethod == method,
                                    onClick = { paymentMethod = method },
                                    label = { Text(method) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFFFA502),
                                        selectedLabelColor = Color.Black,
                                        containerColor = Color(0xFF2E3349),
                                        labelColor = Color.LightGray
                                    ),
                                    border = null
                                )
                            }
                        }

                        // Free Fire Game Character Name / In-Game ID
                        OutlinedTextField(
                            value = gameId,
                            onValueChange = { gameId = it },
                            label = { Text("Free Fire Name / UID") },
                            colors = TextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color(0xFF12141C),
                                unfocusedContainerColor = Color(0xFF12141C),
                                focusedLabelColor = Color(0xFFFFA502),
                                cursorColor = Color(0xFFFFA502)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("deposit_gameid_field")
                        )

                        // Screenshot proof Picker Panel
                        Text(
                            text = "Payment Validation Screenshot",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF12141C))
                                .border(1.dp, Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .clickable { pickerLauncher.launch("image/*") }
                                .testTag("screenshot_picker_box"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (screenshotUri != null) {
                                AsyncImage(
                                    model = screenshotUri,
                                    contentDescription = "Payment screenshot upload preview",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.4f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = Color.White)
                                        Text("Change Image", color = Color.White, fontSize = 12.sp)
                                    }
                                }
                            } else {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.CloudUpload, contentDescription = "Upload icon", tint = Color(0xFFFF4E50), modifier = Modifier.size(32.dp))
                                    Text("Pick Payment Receipt Image", color = Color.LightGray, fontSize = 12.sp)
                                    Text("Supports JPEG, PNG", color = Color.Gray, fontSize = 10.sp)
                                }
                            }
                        }

                        formError?.let {
                            Text(it, color = Color.Red, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }

                        Button(
                            onClick = {
                                val amtDouble = depositAmount.toDoubleOrNull()
                                if (amtDouble == null || amtDouble <= 0) {
                                    formError = "Please write a valid transaction amount"
                                    return@Button
                                }
                                if (screenshotUri == null) {
                                    formError = "Please select a payment screenshot / proof of receipt"
                                    return@Button
                                }
                                if (gameId.isBlank()) {
                                    formError = "Please insert your Free Fire Character ID"
                                    return@Button
                                }

                                formError = null
                                viewModel.uploadDepositProof(
                                    context = context,
                                    imageUri = screenshotUri!!,
                                    amount = amtDouble,
                                    paymentMethod = paymentMethod,
                                    gameId = gameId
                                )
                                // Clear
                                screenshotUri = null
                            },
                            enabled = !isUploading,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4E50)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_deposit_button")
                        ) {
                            if (isUploading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            } else {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                                    Text("Submit Payment Slip", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            } else {
                // Withdrawal Form
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Cash Out Earnings",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Request withdrawal directly. Funds will be verified manually by an admin and settled to your UPI/Paytm/bKash, usually within 1-3 hours.",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )

                        // Amount field
                        OutlinedTextField(
                            value = withdrawAmount,
                            onValueChange = { withdrawAmount = it },
                            label = { Text("Amount to Cash Out") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = TextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color(0xFF12141C),
                                unfocusedContainerColor = Color(0xFF12141C),
                                focusedLabelColor = Color(0xFFFFA502),
                                cursorColor = Color(0xFFFFA502)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("withdraw_amount_field")
                        )

                        // Quick withdrawal selections
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("100", "200", "500", "1000").forEach { amount ->
                                AssistChip(
                                    onClick = { withdrawAmount = amount },
                                    label = { Text(amount) },
                                    colors = AssistChipDefaults.assistChipColors(
                                        labelColor = if (withdrawAmount == amount) Color.White else Color.LightGray,
                                        containerColor = if (withdrawAmount == amount) Color(0xFFFF4E50) else Color(0xFF2E3349)
                                    ),
                                    border = null
                                )
                            }
                        }

                        // Cashout Method Selection
                        Text("Select Payout Channel", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("UPI", "Paytm", "Bkash").forEach { method ->
                                FilterChip(
                                    selected = withdrawMethod == method,
                                    onClick = { withdrawMethod = method },
                                    label = { Text(method) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFFFA502),
                                        selectedLabelColor = Color.Black,
                                        containerColor = Color(0xFF2E3349),
                                        labelColor = Color.LightGray
                                    ),
                                    border = null
                                )
                            }
                        }

                        // Gamer ID / Payout Detail (e.g. upi address)
                        OutlinedTextField(
                            value = withdrawGameId,
                            onValueChange = { withdrawGameId = it },
                            label = { Text("Enter payout address or UPI Phone No.") },
                            colors = TextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color(0xFF12141C),
                                unfocusedContainerColor = Color(0xFF12141C),
                                focusedLabelColor = Color(0xFFFFA502),
                                cursorColor = Color(0xFFFFA502)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("withdraw_address_field")
                        )

                        withdrawError?.let {
                            Text(it, color = Color.Red, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val amtDouble = withdrawAmount.toDoubleOrNull()
                                if (amtDouble == null || amtDouble <= 0) {
                                    withdrawError = "Please input a valid positive amount"
                                    return@Button
                                }
                                if (amtDouble > balance) {
                                    withdrawError = "Maximum limit exceeded based on current balance INR $balance"
                                    return@Button
                                }
                                if (withdrawGameId.isBlank()) {
                                    withdrawError = "Payout address / registered ID cannot be empty"
                                    return@Button
                                }

                                withdrawError = null
                                viewModel.submitWithdrawal(
                                    amount = amtDouble,
                                    paymentMethod = withdrawMethod,
                                    gameId = withdrawGameId
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA502)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_withdraw_button")
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Color.Black)
                                Text("Withdraw Coins", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Ledger/Transaction History Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Transaction History",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${transactions.size} records",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }

        // History list items
        if (transactions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.HistoryToggleOff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No transactions logged yet", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            items(transactions.sortedByDescending { it.timestamp }) { tx ->
                TransactionRowItem(tx)
            }
        }
    }
}

@Composable
fun BalanceCard(balance: Double) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFF4E50), // Red flame
                            Color(0xFFF9D423)  // Gold sunshine
                        )
                    )
                )
        ) {
            // Stylized background geometric rings
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.08f),
                    radius = size.maxDimension * 0.4f,
                    center = androidx.compose.ui.geometry.Offset(size.width * 0.85f, size.height * 0.3f)
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.05f),
                    radius = size.maxDimension * 0.6f,
                    center = androidx.compose.ui.geometry.Offset(size.width * 0.85f, size.height * 0.3f)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.LocalFireDepartment,
                            contentDescription = "Wallet Icon",
                            tint = Color.White
                        )
                        Text(
                            text = "BATTLE WALLET",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                    }
                    Text(
                        text = "UID: GamerTitan",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "₹",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 5.dp)
                    )
                    Text(
                        text = String.format(Locale.getDefault(), "%,.2f", balance),
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Play contests & turn your gaming skills into actual earnings",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun TabButton(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0xFFFF4E50) else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (selected) Color.White else Color.Gray,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

@Composable
fun TransactionRowItem(tx: Transaction) {
    val formatter = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val dateString = remember(tx.timestamp) { formatter.format(Date(tx.timestamp)) }

    val statusColor = when (tx.status) {
        "approved" -> Color(0xFF2ED573)
        "rejected" -> Color(0xFFFF4757)
        else -> Color(0xFFFFA502) // pending
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Type Icon
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (tx.type == "Deposit") Color(0xFF2ED573).copy(alpha = 0.15f)
                            else Color(0xFFFF4757).copy(alpha = 0.15f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (tx.type == "Deposit") Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                        contentDescription = tx.type,
                        tint = if (tx.type == "Deposit") Color(0xFF2ED573) else Color(0xFFFF4757)
                    )
                }

                // Title info
                Column {
                    Text(
                        text = "${tx.type} (${tx.paymentMethod})",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Ref: ${tx.id}",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                    Text(
                        text = dateString,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }

            // Numeric info and status tag
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${if (tx.type == "Deposit") "+" else "-"} ₹${tx.amount.toInt()}",
                    color = if (tx.type == "Deposit") Color(0xFF2ED573) else Color(0xFFFF4757),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = tx.status.uppercase(Locale.getDefault()),
                        color = statusColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
