package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.Transaction
import com.example.viewmodel.FFViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminDashboard(viewModel: FFViewModel) {
    val pendingList by viewModel.pendingTransactions.collectAsState()
    var selectedScreenshotUrl by remember { mutableStateOf<String?>(null) }

    // Aggregate stats
    val pendingDeposits = remember(pendingList) { pendingList.filter { it.type == "Deposit" } }
    val pendingWithdrawals = remember(pendingList) { pendingList.filter { it.type == "Withdrawal" } }
    val totalPendingAmount = remember(pendingList) { pendingList.sumOf { it.amount } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF12141C))
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Multi-Card Stats Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AdminStatCard(
                title = "Pending Deposits",
                value = pendingDeposits.size.toString(),
                color = Color(0xFF2ED573),
                modifier = Modifier.weight(1f)
            )
            AdminStatCard(
                title = "Pending Claims",
                value = pendingWithdrawals.size.toString(),
                color = Color(0xFFFF4E50),
                modifier = Modifier.weight(1f)
            )
            AdminStatCard(
                title = "Est. Total Value",
                value = "₹${totalPendingAmount.toInt()}",
                color = Color(0xFFFFA502),
                modifier = Modifier.weight(1.1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Verification Queue (${pendingList.size} requests)",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            // Force refreshing/fetching helper
            IconButton(onClick = { viewModel.fetchPendingTransactions() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh verification list", tint = Color.LightGray)
            }
        }

        if (pendingList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FactCheck,
                        contentDescription = "Review cleared",
                        tint = Color(0xFF2ED573),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Everything is Verified",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Nice job! The manual transaction queue is currently empty.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(pendingList, key = { it.id }) { tx ->
                    PendingTransactionCard(
                        transaction = tx,
                        onApprove = { viewModel.approveTransaction(tx.id) },
                        onReject = { viewModel.rejectTransaction(tx.id) },
                        onImageClick = { url -> selectedScreenshotUrl = url }
                    )
                }
            }
        }
    }

    // Modal Image Screen Detail Dialog
    selectedScreenshotUrl?.let { url ->
        ImageVerificationDialog(
            imageUrl = url,
            onDismiss = { selectedScreenshotUrl = null }
        )
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = title, color = Color.Gray, fontSize = 10.sp)
            Text(text = value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PendingTransactionCard(
    transaction: Transaction,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onImageClick: (String) -> Unit
) {
    val formatter = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val dateString = remember(transaction.timestamp) { formatter.format(Date(transaction.timestamp)) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pending_card_${transaction.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Type, ID, and Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (transaction.type == "Deposit") Color(0xFF2ED573).copy(alpha = 0.15f)
                                else Color(0xFFFF4E50).copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (transaction.type == "Deposit") Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                            contentDescription = transaction.type,
                            tint = if (transaction.type == "Deposit") Color(0xFF2ED573) else Color(0xFFFF4E50),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "${transaction.type} Request",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Text(
                    text = dateString,
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Divider(color = Color.White.copy(alpha = 0.05f))

            // Details: Amount, Payment Method, Free Fire Name
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("PLAYER IGN", color = Color.Gray, fontSize = 9.sp)
                    Text(transaction.gameId ?: "N/A", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("CHANNEL", color = Color.Gray, fontSize = 9.sp)
                    Text(transaction.paymentMethod, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("AMOUNT DUE", color = Color.Gray, fontSize = 9.sp)
                    Text("₹${transaction.amount.toInt()}", color = Color(0xFFFFA502), fontSize = 16.sp, fontWeight = FontWeight.Black)
                }
            }

            // Receipt Screenshot Link/Box (ONLY for Deposits)
            if (transaction.type == "Deposit" && !transaction.screenshotUrl.isNullOrEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF12141C))
                        .border(1.dp, Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                        .clickable { onImageClick(transaction.screenshotUrl) }
                        .testTag("verify_screenshot_box"),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = transaction.screenshotUrl,
                        contentDescription = "User payment voucher",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    // Tint overlay with magnifying glass icon
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "View receipt", tint = Color.White, modifier = Modifier.size(18.dp))
                            Text("TAP TO INSPECT SLIP", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Reject Button
                Button(
                    onClick = onReject,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4757).copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("reject_button_${transaction.id}")
                ) {
                    Text("REJECT", color = Color(0xFFFF4757), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Approve Button
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2ED573)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1.5f)
                        .height(38.dp)
                        .testTag("approve_button_${transaction.id}")
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Text("APPROVE & VERIFY", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ImageVerificationDialog(
    imageUrl: String,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F)),
            modifier = Modifier
                .fillMaxWidth()
                .height(450.dp)
                .testTag("verification_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Payment Screenshot Verification", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                ) {
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = "Expanded screenshot slip",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4E50)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Inspection", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
