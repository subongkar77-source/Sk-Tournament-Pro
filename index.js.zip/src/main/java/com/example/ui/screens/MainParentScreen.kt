package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.viewmodel.FFViewModel

@Composable
fun MainParentScreen(viewModel: FFViewModel = viewModel()) {
    var activeTab by remember { mutableStateOf("tournaments") } // "tournaments", "wallet", "admin"
    val uiMessage by viewModel.uiMessage.collectAsState()
    val isSimulatedMode by viewModel.isSimulatedMode.collectAsState()
    val userBalance by viewModel.userBalance.collectAsState()

    // Slide and fade banner mechanism for notification popups
    LaunchedEffect(uiMessage) {
        if (uiMessage != null) {
            kotlinx.coroutines.delay(4000)
            viewModel.clearUiMessage()
        }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1A1D24))
            ) {
                // Top status bar safe area padding
                Spacer(modifier = Modifier.height(32.dp))

                // Brand header row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFF4E50)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.SportsEsports,
                                contentDescription = "App logo logo",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                "BOOYAH ARENA",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                "Gamer: ${viewModel.currentUserName}",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Balance Display Box
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF2E3349))
                            .clickable { activeTab = "wallet" }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.MonetizationOn,
                            contentDescription = "Wallet Balance",
                            tint = Color(0xFFFFA502),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            "₹${userBalance.toInt()}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                // Dual Mode Switcher Banner (Interactive Simulation vs Live Backend API)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSimulatedMode) Color(0xFFFFA502).copy(alpha = 0.1f) else Color(0xFF2ED573).copy(alpha = 0.1f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isSimulatedMode) "SIMULATOR MODE ENABLED" else "LIVE RETROFIT BACKEND MODE",
                            color = if (isSimulatedMode) Color(0xFFFFA502) else Color(0xFF2ED573),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = if (isSimulatedMode) "Runs self-contained local state workflows offline" else "Sends actual HTTP/Multipart REST requests to Port 5000",
                            color = Color.LightGray,
                            fontSize = 9.sp
                        )
                    }

                    Switch(
                        checked = !isSimulatedMode,
                        onCheckedChange = { isLive -> viewModel.setSimulatedMode(!isLive) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF2ED573),
                            checkedTrackColor = Color(0xFF2ED573).copy(alpha = 0.3f),
                            uncheckedThumbColor = Color(0xFFFFA502),
                            uncheckedTrackColor = Color(0xFFFFA502).copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .scale(0.7f)
                            .testTag("mode_toggle")
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Divider(color = Color.White.copy(alpha = 0.08f))
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1A1D24),
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = activeTab == "tournaments",
                    onClick = { activeTab = "tournaments" },
                    label = { Text("Tourneys", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = {
                        Icon(
                            if (activeTab == "tournaments") Icons.Default.EmojiEvents else Icons.Default.EmojiEvents,
                            contentDescription = "Tournaments"
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color.White,
                        indicatorColor = Color(0xFFFF4E50),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tourneys")
                )

                NavigationBarItem(
                    selected = activeTab == "wallet",
                    onClick = { activeTab = "wallet"; viewModel.fetchTransactions() },
                    label = { Text("Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = {
                        Icon(
                            if (activeTab == "wallet") Icons.Default.AccountBalanceWallet else Icons.Default.AccountBalanceWallet,
                            contentDescription = "Wallet"
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color.White,
                        indicatorColor = Color(0xFFFF4E50),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_wallet")
                )

                NavigationBarItem(
                    selected = activeTab == "admin",
                    onClick = { activeTab = "admin"; viewModel.fetchPendingTransactions() },
                    label = { Text("Admin DB", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = {
                        Icon(
                            if (activeTab == "admin") Icons.Default.AdminPanelSettings else Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Area"
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color.White,
                        indicatorColor = Color(0xFFFF4E50),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_admin")
                )
            }
        },
        containerColor = Color(0xFF12141C)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen switching
            when (activeTab) {
                "tournaments" -> TournamentsScreen(viewModel)
                "wallet" -> WalletScreen(viewModel)
                "admin" -> AdminDashboard(viewModel)
            }

            // Slide down system popup overlay banner
            AnimatedVisibility(
                visible = uiMessage != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                uiMessage?.let { msg ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3349)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFFF4E50).copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFFF4E50))
                            Text(
                                text = msg,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearUiMessage() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
