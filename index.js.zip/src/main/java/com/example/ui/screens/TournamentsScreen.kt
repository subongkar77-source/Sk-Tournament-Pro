package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Tournament
import com.example.viewmodel.FFViewModel

@Composable
fun TournamentsScreen(viewModel: FFViewModel) {
    val tournaments by viewModel.tournaments.collectAsState()
    var tourneyFilter by remember { mutableStateOf("All") } // "All", "Solo", "CS", "Lone Wolf"

    val filteredList = remember(tournaments, tourneyFilter) {
        if (tourneyFilter == "All") tournaments
        else tournaments.filter { it.type.contains(tourneyFilter, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF12141C))
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Hero Fire Promotion Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1.2f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Season Live Arena",
                        color = Color(0xFFFF4E50),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Solo, Squad & Duels",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Register using credit coins and claim your BOOYAH winnings instantly.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.SportsEsports,
                    contentDescription = null,
                    tint = Color(0xFFFF4E50).copy(alpha = 0.8f),
                    modifier = Modifier.size(56.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Category Selection
        Text(
            text = "Choose Battle Category",
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("All", "Solo", "CS", "Lone Wolf").forEach { filter ->
                FilterChip(
                    selected = tourneyFilter == filter,
                    onClick = { tourneyFilter = filter },
                    label = { Text(filter) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFFF4E50),
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF1D212F),
                        labelColor = Color.LightGray
                    ),
                    border = null,
                    modifier = Modifier.testTag("filter_chip_$filter")
                )
            }
        }

        // Active listing
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (filteredList.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No match matches this filter.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            } else {
                items(filteredList, key = { it.id }) { tourney ->
                    TournamentItemCard(
                        tournament = tourney,
                        onRegister = { viewModel.registerForTournament(tourney.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun TournamentItemCard(
    tournament: Tournament,
    onRegister: () -> Unit
) {
    val progress = remember(tournament) {
        if (tournament.slotsTotal > 0) {
            (tournament.slotsTotal - tournament.slotsAvailable).toFloat() / tournament.slotsTotal
        } else {
            0f
        }
    }

    val typeColor = when (tournament.type) {
        "Solo" -> Color(0xFFFFC107)
        "Lone Wolf" -> Color(0xFF03A9F4)
        else -> Color(0xFFE040FB) // CS Clash Squad
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tournament_card_${tournament.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1D212F)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Row 1: Badges & Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(typeColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = tournament.type.uppercase(),
                        color = typeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                    Text(text = tournament.map, color = Color.Gray, fontSize = 11.sp)
                }
            }

            Text(
                text = tournament.title,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            // Row 2: Date & Time Schedule
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                Text(
                    text = "${tournament.date} @ ${tournament.time}",
                    color = Color.LightGray,
                    fontSize = 12.sp
                )
            }

            Divider(color = Color.White.copy(alpha = 0.05f))

            // Row 3: Economic stats (Prize Pool & Entry Fee)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("PRIZE POOL", color = Color.Gray, fontSize = 9.sp)
                    Text("₹${tournament.prizePool}", color = Color(0xFF2ED573), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("ENTRY FEE", color = Color.Gray, fontSize = 9.sp)
                    Text("₹${tournament.entryFee}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }

            Divider(color = Color.White.copy(alpha = 0.05f))

            // Row 4: Spots left progress indicator & REGISTER action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (tournament.slotsAvailable > 0) "Spots left: ${tournament.slotsAvailable}" else "Match Filled",
                            color = if (tournament.slotsAvailable > 0) Color.LightGray else Color(0xFFFF4757),
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${tournament.slotsTotal - tournament.slotsAvailable}/${tournament.slotsTotal}",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFFFF4E50),
                        trackColor = Color(0xFF12141C)
                    )
                }

                Button(
                    onClick = onRegister,
                    enabled = tournament.slotsAvailable > 0 && tournament.status == "Registering",
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (tournament.slotsAvailable > 0) Color(0xFFFF4E50) else Color.Gray
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("register_button_${tournament.id}")
                ) {
                    Text(
                        text = if (tournament.slotsAvailable > 0) "JOIN MATCH" else "FULL",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (tournament.slotsAvailable > 0) Color.White else Color.LightGray
                    )
                }
            }
        }
    }
}
